#!/usr/bin/env bash
set -euo pipefail

# Installation des dépendances pour Kaspa Pool

# Copier .env si absent
if [ ! -f ".env" ]; then
  cp .env.example .env
  echo "→ Copié .env.example → .env (à remplir si nécessaire)"
fi

# Installation backend
echo "→ Installation des dépendances backend"
cd backend
npm ci
cd ..

# Installation stratum
echo "→ Installation des dépendances stratum"
cd stratum
npm ci
cd ..

echo "✅ Installation terminée. Vérifie ton .env, puis démarre avec ./start.sh ou les services systemd."
