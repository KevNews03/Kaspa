import dotenv from 'dotenv';
import express from 'express';
import { MongoClient } from 'mongodb';

dotenv.config();
const app = express();
const port = process.env.PORT || 3001;

app.use(express.json());

const client = new MongoClient(process.env.MONGODB_URI);
await client.connect();
const db = client.db();

app.get('/api/stats', async (req, res) => {
  const stats = await db.collection('pool_stats').findOne({}, { sort: { time: -1 } }) || {};
  res.json({
    hashrate: stats.hashrate || 0,
    miners: stats.miners || 0,
    blocksFound: stats.blocksFound || 0,
    lastPayment: stats.lastPayment || null
  });
});

app.get('/api/miner/:address', async (req, res) => {
  const miner = await db.collection('miners').findOne({ address: req.params.address });
  if (!miner) return res.status(404).send('Miner not found');
  res.json({
    address: miner.address,
    hashrate: miner.hashrate || 0,
    shares: miner.shares || 0,
    lastPayment: miner.lastPayment || null,
    active: miner.active || false
  });
});

app.listen(port, () => console.log(`API listening on http://localhost:${port}`));
