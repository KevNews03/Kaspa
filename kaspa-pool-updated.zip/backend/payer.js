import dotenv from 'dotenv';
import fetch from 'node-fetch';
import { MongoClient } from 'mongodb';

dotenv.config();

// RPC configuration
const host = process.env.KASPAD_RPC_HOST;
const port = process.env.KASPAD_RPC_PORT;
const user = process.env.KASPAD_RPC_USER;
const pass = process.env.KASPAD_RPC_PASS;
const rpcUrl = `http://${host}:${port}/rpc`;

const auth = Buffer.from(`${user}:${pass}`).toString('base64');
const headers = {
  'Content-Type': 'application/json',
  'Authorization': `Basic ${auth}`,
};

async function rpc(method, params = []) {
  const res = await fetch(rpcUrl, {
    method: 'POST',
    headers,
    body: JSON.stringify({ jsonrpc: '2.0', id: 1, method, params }),
  });
  const { result, error } = await res.json();
  if (error) throw new Error(error.message);
  return result;
}

// Example: retrieve network info
async function getNetworkStats() {
  return rpc('getNetworkInfo');
}

// Payment processor (à adapter selon ta structure MongoDB)
async function processPayments() {
  const mongoUrl = `mongodb://${process.env.DB_USER}:${process.env.DB_PASS}@${process.env.DB_HOST}:${process.env.DB_PORT}/${process.env.DB_NAME}`;
  const client = new MongoClient(mongoUrl);
  await client.connect();
  const db = client.db(process.env.DB_NAME);
  // Logique de calcul des paiements ici...
  client.close();
}

// Exports
export { rpc, getNetworkStats, processPayments };
