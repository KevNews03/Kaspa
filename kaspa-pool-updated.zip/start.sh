#!/bin/bash
set -e
echo "Starting MongoDB..."
mongod --dbpath ./data --fork --logpath logs/mongo.log
echo "Starting backend..."
cd backend && nohup npm start > ../logs/backend.log 2>&1 &
cd ..
echo "Starting stratum..."
cd stratum && nohup npm start > ../logs/stratum.log 2>&1 &
cd ..
echo "All started."
