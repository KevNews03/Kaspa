# Kaspa Mining Pool Real Integration

## Setup
cp .env.example .env
chmod +x install.sh start.sh
./install.sh
mkdir -p logs data
./start.sh

Real Stratum uses getBlockTemplate & submitBlock RPC.
Real payments via generateTransaction & submitTransaction RPC.
