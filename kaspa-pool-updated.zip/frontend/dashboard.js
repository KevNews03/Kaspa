// dashboard.js

const ctx = document.getElementById('poolChart').getContext('2d');
const poolChart = new Chart(ctx, {
  type: 'line',
  data: {
    labels: Array(10).fill(''),
    datasets: [{
      label: 'Pool Hashrate (H/s)',
      data: Array(10).fill(0),
      borderColor: 'cyan',
      borderWidth: 2
    }]
  },
  options: {
    scales: { y: { beginAtZero: true } }
  }
});

async function fetchPool() {
  const res = await fetch('/api/stats');
  const p = await res.json();
  document.getElementById('pool-hashrate').innerText = p.hashrate + ' H/s';
  document.getElementById('pool-miners').innerText = p.miners;
  document.getElementById('pool-blocks').innerText = p.blocksFound;
  document.getElementById('pool-payment').innerText = p.lastPayment || '–';
  poolChart.data.datasets[0].data.push(p.hashrate);
  poolChart.data.datasets[0].data.shift();
  poolChart.update();
}

async function loadMiner() {
  const addr = document.getElementById('minerAddress').value.trim();
  if (!addr.startsWith('kaspa:')) { alert('Adresse Kaspa invalide'); return; }
  const res = await fetch(`/api/miner/${addr}`);
  if (!res.ok) { alert('Mineur non trouvé'); return; }
  const m = await res.json();
  document.getElementById('miner-hashrate').innerText = m.hashrate + ' H/s';
  document.getElementById('miner-shares').innerText = m.shares;
  document.getElementById('miner-payment').innerText = m.lastPayment || '–';
  document.getElementById('miner-status').innerText = m.active ? 'Active' : 'Inactive';
  document.getElementById('minerSection').classList.remove('d-none');
}

fetchPool();
setInterval(fetchPool, 10000);
