// admin.js

async function login(e) {
  e.preventDefault();
  const user = document.getElementById('user').value;
  const pass = document.getElementById('pass').value;
  const res = await fetch('/api/admin/login', {
    method: 'POST', headers: {'Content-Type':'application/json'},
    body: JSON.stringify({ username: user, password: pass })
  });
  document.getElementById('msg').innerText = res.ok ? 'Connexion réussie' : 'Échec de la connexion';
}
