import dotenv from 'dotenv';
import net from 'net';
import { v4 as uuidv4 } from 'uuid';
import fetch from 'node-fetch';

dotenv.config();
const PORT = process.env.STRATUM_PORT || 3333;
const rpcUrl = `http://${process.env.RPC_HOST}:${process.env.RPC_PORT}`;

async function rpc(method, params={}) {
  const res = await fetch(rpcUrl, {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({ jsonrpc:'2.0', id:1, method, params })
  });
  const { result, error } = await res.json();
  if (error) throw new Error(error.message);
  return result;
}

const server = net.createServer(socket => {
  let minerAddr;
  socket.on('data', async data => {
    for (const msg of data.toString().split('\n')) {
      if (!msg) continue;
      const req = JSON.parse(msg);
      if (req.method === 'mining.subscribe') {
        socket.write(JSON.stringify({ id:req.id, result:[[["mining.set_difficulty","1"]],"sess"], error:null }) + '\n');
      }
      if (req.method === 'mining.authorize') {
        minerAddr = req.params[0];
        socket.write(JSON.stringify({ id:req.id, result:true, error:null }) + '\n');
        const tmpl = await rpc('getBlockTemplate', {});
        socket.write(JSON.stringify({ id:null, method:'mining.notify', params:[
          tmpl.jobId||uuidv4(),
          tmpl.blockTemplateBlob,
          tmpl.networkTarget
        ] }) + '\n');
      }
      if (req.method === 'mining.submit') {
        // TODO: validate share
        const submit = await rpc('submitBlock', { blockHex:req.params[2] });
        socket.write(JSON.stringify({ id:req.id, result:submit, error:null }) + '\n');
      }
    }
  });
});
server.listen(PORT, () => console.log(`Stratum listening on ${PORT}`));
